---
title: Gateway to Fraud Detect Transaction Field Mapping
author: jill.oliver@firstdata.com
---

