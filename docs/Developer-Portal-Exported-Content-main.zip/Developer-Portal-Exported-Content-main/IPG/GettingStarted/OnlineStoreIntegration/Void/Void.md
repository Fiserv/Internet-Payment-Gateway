---
title: Void
author: steffen.dangel@firstdata.de
---

## Step 4: Voiding a Transaction

If your customer has canceled the order or you detected suspicious order details, you can void the transaction referencing to the original Transaction ID.

> [See how to create the API request for a Void][1]

 [1]: http://test-ndpfdc.pantheonsite.io/org/gateway/docs/api#void-a-transaction
