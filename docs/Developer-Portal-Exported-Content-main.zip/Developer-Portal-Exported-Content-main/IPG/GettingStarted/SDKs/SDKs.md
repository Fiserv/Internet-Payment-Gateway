---
title: SDKs
author: annavonbriesen@gmail.com
---

**Github Repositories**

  * [C# .NET][1]
  * [Python][2]
  * [Ruby][3]
  * [Java][4]
  * [PHP][5]
  * [Javascript][6]

**Packages**

  * Composer
  * Maven
  * NPM
  * NuGet
  * pip
  * Ruby Gem

 [1]: https://github.com/GBSEcom/DotNet
 [2]: https://github.com/GBSEcom/Python
 [3]: https://github.com/GBSEcom/Ruby
 [4]: https://github.com/GBSEcom/java
 [5]: https://github.com/GBSEcom/PHP
 [6]: https://github.com/GBSEcom/NPM
